from delta.tables import DeltaTable
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.window import Window
from pyspark.errors import AnalysisException
import pyspark.sql.types as T
import pyspark.sql.functions as F
from datetime import datetime

spark: SparkSession = None

class ChangeDataFeed:

    def __init__(self, target_entity: str, target_entity_table_path: str):
        """ The constructor of the CDF Helper only takes

        Args:
            target_entity (str): Target Entity Name of the Delta Table
            target_entity_table_path (str): Path to Target Entity
        """
        self.metadata_path = target_entity_table_path + '/_cdf_metadata'
        self.target_entity = target_entity


        #TBD: add a drop (delta.tablename). If Delta Table gets Deleted it throws analysis Exception
        #check if the meta delta Table exists and if not create it.
        delta_table_exists = DeltaTable.isDeltaTable(spark, self.metadata_path)

        if delta_table_exists:
            metadata_schema = T.StructType([
                T.StructField('sourceEntity', T.StringType(), False),
                T.StructField('versionProcessed', T.IntegerType(), False),
                T.StructField('createdAt', T.TimestampType(), False)
            ])
            
            (
                DeltaTable.createIfNotExists(spark)
                        .location(self.metadata_path)
                        .addColumns(metadata_schema)
                        .execute()
            )

        self.metadata_table = DeltaTable.forPath(self.metadata_path)


    def get_latest_source_version(self, source_entity_table_path: str) -> int:
        """ Get most recent version number of a Source Delta Table

        Args:
            source_entity_table_path (str): Path to the most recent version number

        Returns:
            int: Most recent version number 
        """
        return (
            DeltaTable.forPath(spark, source_entity_table_path)
                      .history()
                      .select(F.max(F.col('version')))
                      .collect()[0][0]
        )

    def get_source_table_creation_time(self, source_entity_table_path: str) -> datetime:
        """Get creation Time of Delta Table.

        Args:
            source_entity_table_path (str): Path to the Delta Table.

        Returns:
            datetime: Creation Time
        """
        return (
            DeltaTable.forPath(spark, source_entity_table_path)
                    .history()
                    .orderBy(F.col("version").asc())
                    .select('timestamp')
                    .collect()[0][0]
        )

    def get_last_processed_version(self, source_entity: str) -> tuple[int | None, datetime | None]:
        """Get the last processed version of a specified source Table.

        Args:
            source_entity (str): source entity name

        Returns:
            tuple[int | None, datetime | None]: Returns version number and processing time
        """
        query_result = (
            self.metadata_table
                .toDF()
                .where(f"sourceEntity = '{source_entity}'")
                .select(
                    F.max(F.col('versionProcessed')).alias('versionProcessed'),
                    F.max(F.col('createdAt')).alias('createdAt')
                )
                .collect()[0]
        )
        return query_result['versionProcessed'], query_result['createdAt']
    
    def load_with_cdf_all_commits(self, source_entity: str, source_entity_table_path: str) -> tuple[DataFrame, int]:
        """ Load change data feed Dataframe with all new commit Versions per row.
        Returns an empty dataframe with the schema of the source table if there has been no new version
        compared to the metadata table.
        Returns a dataframe containing the entire source table in the following cases:
            - There is no entry for the source table in the metadata table
            - The source table has been recreated since the timestamp `last_processed_at` in the metadata table
            - The starting version given by the metadata table is not available anymore (i.e. due to vacuum)

        Args:
            source_entity (str): source entity name
            source_entity_table_path (str): source entity 

        Returns:
            tuple[DataFrame, int]:  Returns Dataframe and source version processed
        """
        latest_source_version = self.get_latest_source_version(source_entity_table_path)
        source_table_creation_time = self.get_source_table_creation_time(source_entity_table_path)
        last_processed_version, last_processed_at = self.get_last_processed_version(source_entity)

        # Load entire table if there is no entry for the source table in the metadata table
        if (last_processed_version is None):
            df = spark.read.format('delta').load(source_entity_table_path)
        
        # Load entire table if the source table has been recreated since the timestamp `last_processed_at` in the metadata table
        elif (last_processed_at < source_table_creation_time):
            self.metadata_table.delete(f"sourceEntity = '{source_entity}'")
            df = spark.read.format('delta').load(source_entity_table_path)
        
        # Return an empty table if there has been no new version compared to the metadata table
        elif (latest_source_version == last_processed_version):
            df = spark.createDataFrame([], schema=DeltaTable.forPath(spark, source_entity_table_path).toDF().schema)
        
        # Otherwise load only the changes since the last version
        else:
            # Try-Except needed for the case that the needed startingVersion is not available anymore (i.e. due to vacuum)
            # in that case also return the entire table
            try:
                df = (
                    spark.read.format('delta')
                        .option('readChangeFeed', 'true')
                        .option('startingVersion', last_processed_version + 1)
                        .option('endingVersion', latest_source_version)
                        .load(source_entity_table_path)
                )
            except AnalysisException:
                df = spark.read.format('delta').load(source_entity_table_path)
        
        return df, latest_source_version
    
    def load_with_cdf_cleaned(self,
                              source_entity: str,
                              source_entity_table_path: str,
                              identifier_cols: list[str],
                              change_types: list[str]=['update_postimage', 'insert'],
                              drop_internal_columns: bool=True
                              ) -> tuple[DataFrame, int]:
        """Load change data feed Dataframe with most recent entry per row

        Args:
            source_entity (str): source entity name
            source_entity_table_path (str): path to source table
            identifier_cols (list[str]): list of identifier columns for table
            change_types (list[str], optional): Specifies change types to return. Defaults to ['update_postimage', 'insert'].
            drop_internal_columns (bool, optional): Whether internal CDF columns are supposed to be dropped. Defaults to True.

        Returns:
            tuple[DataFrame, int]: Returns Dataframe and source version processed
        """
        
        df, latest_source_version = self.load_with_cdf_all_commits(source_entity, source_entity_table_path)
        if '_commit_version' in df.columns:
            window = Window().partitionBy(*identifier_cols).orderBy(F.col('_commit_version').desc())
            df_cleaned = (
                df.where(F.col('_change_type').isin(change_types))
                  .withColumn("_max", F.first(F.col('_commit_version')).over(window))
                  .where("_max = _commit_version")
            )
            if drop_internal_columns:
                df_cleaned = df_cleaned.drop('_max', '_commit_version', '_change_type', '_commit_timestamp')
            return df_cleaned, latest_source_version
        else:
            return df, latest_source_version

    def update_cdf_metadata_table(self, source_entity: str, latest_source_version: int) -> None:
        """Update the meta table with new processing

        Args:
            source_entity (str): source entity name
            latest_source_version (int): latest version processed
        """
        temp_schema = T.StructType([
            T.StructField('sourceEntity', T.StringType(), False),
            T.StructField('versionProcessed', T.IntegerType(), False),
            T.StructField('createdAt', T.TimestampType(), False)
        ])
        df_temp = spark.createDataFrame([(source_entity, latest_source_version, datetime.utcnow()),], schema=temp_schema)

        df_temp.write.mode('append').format('delta').save(self.metadata_path)