from pyspark.sql import SparkSession
 
class maintenance:

    def __init__(self, sparkSession: SparkSession) -> None:
        self.spark = sparkSession

    # vacuum
   
    def vacuum_table(self, db_name: str, table_name: str, retention_days: int, is_dry_run=False) -> None:
        # calculate retention hours and run vacuum
        retention_hours = retention_days * 24
        if is_dry_run:
            df = self.spark.sql(f"VACUUM {db_name}.{table_name} RETAIN {retention_hours} HOURS DRY RUN")
            print(f"{db_name}.{table_name} files to be deleted: {df.count()}")
        else:
                self.spark.sql(f"VACUUM {db_name}.{table_name} RETAIN {retention_hours} HOURS")


    def vacuum_database(self, database_name: str, retention_days: int, is_dry_run=False) -> None:
        # get all tables in database
        tables = self.spark.sql(f"SHOW tables IN {database_name}").select('tableName').collect()
        # run vacuum function on tables
        for table in tables:
            self.vacuum_table(database_name, table[0], retention_days, is_dry_run)
    

    def optimize_table(self, db_name: str, table_name: str) -> None:
        # optimize lake table
        self.spark.sql(f"OPTIMIZE {db_name}.{table_name}")


    def optimize_database(self, database_name: str) -> None:
        # get all tables in database
        tables = self.spark.sql(f"SHOW tables IN {database_name}").select('tableName').collect()
        # run optimize function on tables
        for table in tables:
            self.optimize_table(database_name, table[0])

        
        # FUTURE ENHANCEMENTS VACUUM
        # 1. Loop through file path instead of Lake DB tables 
        # 2. Optimize
        # 3. Dynamisation: use different retention periods per table
            
        # For 3.
        # retention_period_7 = ['dim_1', 'dim2']
        # retention_period_10 = ['fakt_ist', 'fakt_plan']

        # for table in retention_period_7:
        #     maintenance.vacuum_table(database_name, table[0], retention_days, is_dry_run)

        # for table in retention_period_10:
        #     maintenance.vacuum_table(database_name, table[0], retention_days, is_dry_run)