from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import lit, current_timestamp
from pyspark.sql.session import SparkSession
from delta.tables import DeltaTable

class Merge:

    def __init__(self, spark_session: SparkSession, df: DataFrame, delta_table_path: str) -> None:
        
        self.df = df
        self.spark_session = spark_session
        self.delta_table_path = delta_table_path
    
    def __check_uniqueness(self, identifier_columns_list: list[str]) -> bool:
        unique_df = self.df.dropDuplicates(subset=identifier_columns_list)
        return self.df.count() == unique_df.count()
    
    #TODO: Add CreatedOn and UpdatedOn columns
    #TODO: Add delete option
    #TODO: Add primary key option
    def merge_by_identifier_columns(self, identifier_columns_list: list[str], update_unchanged_rows: bool = False) -> str:
        """Merges a dataframe by identifier columns into a delta table.

        Args:
            identifier_columns_list (list[str]): identifier columns list
            update_unchanged_rows (bool, optional): Update rows that have not cchanged in non identifier columns. Defaults to False.

        Returns:
            str: Success message or error message
        """        
        if not self.__check_uniqueness(identifier_columns_list):
            return f'Source data not unique by {identifier_columns_list}'            
      
        other_columns_list = [c for c in self.df.columns if c not in identifier_columns_list]

        merge_conditions = ' AND '.join(str("Source." + c + " = " + "Target." + c) for c in identifier_columns_list)
        matched_conditions = ' OR '.join(str("!(Source." + c + " <=> " + "Target." + c + ")") for c in other_columns_list)

        delta_table_exists = DeltaTable.isDeltaTable(self.spark_session, self.delta_table_path)

        if delta_table_exists == False:
            DeltaTable.createIfNotExists(self.spark_session) \
                .location(self.delta_table_path) \
                .addColumns(self.df.schema) \
                .execute()
        
        delta_table = DeltaTable.forPath(self.spark_session, self.delta_table_path)

        #self.df = self.df.withColumn("CreatedOn", lit(current_timestamp()))
        #self.df = self.df.withColumn("UpdatedOn", lit(current_timestamp()))


        if update_unchanged_rows:
            delta_table.alias('Target') \
                .merge( \
                    source = self.df.alias('Source'), \
                    condition = merge_conditions \
                ) \
                .whenMatchedUpdateAll() \
                .whenNotMatchedInsertAll() \
                .execute()
        else:
            delta_table.alias('Target') \
                .merge( \
                    source = self.df.alias('Source'), \
                    condition = merge_conditions \
                ) \
                .whenMatchedUpdateAll( \
                    condition = matched_conditions \
                ) \
                .whenNotMatchedInsertAll() \
                .execute()
        
        return "Successfully merged table"