class test:

    def __init__(self) -> None:
        pass
    
    def helloworld(self):
        print("hello world!")
    