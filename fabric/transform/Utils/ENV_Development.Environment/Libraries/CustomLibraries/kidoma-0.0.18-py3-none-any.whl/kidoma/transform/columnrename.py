from pyspark.sql import DataFrame
from pyspark.sql import SparkSession

if __name__ == "__main__":
    spark: SparkSession = None

class ColumnRenameException(Exception):
    """Exception class used in the Transform class
    not yet used
    """
    def __init__(self, message: str):
        super().__init__(message)
        
class ColumnRename:
    """A collection of methods to help rename column names.
    """

    def __init__(self):
        pass
    
    def to_pascal_case(self, df: DataFrame, cols: list[str] = None, delimiter: str = "_") -> DataFrame:
        """_summary_

        Args:
            df (_type_): DataFrame to be modified.
            cols (_type_, optional): Columns to be modified, if not all. Defaults to all columns.
            delimiter (str, optional): Delimiters to split by. Defaults to "_".

        Returns:
            _type_: DataFrame with columns renamed.
        """
        return self._iter_over_columns(df, cols, delimiter, self.__pascal)

    def to_camel_case(self, df: DataFrame, cols: list[str] = None, delimiter: str = "_") -> DataFrame:
        """_summary_

        Args:
            df (_type_): DataFrame to be modified.
            cols (_type_, optional): Columns to be modified, if not all. Defaults to all columns.
            delimiter (str, optional): Delimiters to split by. Defaults to "_".

        Returns:
            _type_: DataFrame with columns renamed.
        """
        return self._iter_over_columns(df, cols, delimiter, self.__camel)

    def to_snake_case(self, df: DataFrame, cols: list[str] = None, delimiter: str = "_") -> DataFrame:
        """_summary_

        Args:
            df (_type_): DataFrame to be modified.
            cols (_type_, optional): Columns to be modified, if not all. Defaults to all columns.
            delimiter (str, optional): Delimiters to split by. Defaults to "_".

        Returns:
            _type_: DataFrame with columns renamed.
        """
        return self._iter_over_columns(df, cols, delimiter, self.__snake)

    def _iter_over_columns(self, df, cols, delimiter, transform_string):
        if cols is None:
            cols = df.columns
        for col_name in df.columns:
            if col_name in cols:
                split_list = col_name.split(delimiter)
                df = df.withColumnRenamed(col_name, transform_string(split_list))
        return df

    def __pascal(self, split_list):
        for i, v in enumerate(split_list):
            split_list[i] = v[0].upper() + v[1:].lower()
        new_col_name = "".join(split_list)
        return new_col_name

    def __camel(self, split_list):
        for i, v in enumerate(split_list):
            if i == 0:
                split_list[i] = v.lower() 
            else:
                split_list[i] = v[0].upper() + v[1:].lower()
        new_col_name = "".join(split_list)
        return new_col_name

    def __snake(self, split_list):
        for i, v in enumerate(split_list):
            split_list[i] = v.lower()
        new_col_name = "_".join(split_list)
        return new_col_name
