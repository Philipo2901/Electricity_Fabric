from pyspark.sql import DataFrame
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from decimal import Decimal
import datetime as dt

class DefaultHelperException(Exception):
    """Exception class used in the DefaultHelper class
    """
    def __init__(self, message: str):
        super().__init__(message)    
        
class DefaultHelper:
    """A collection of methods to help with default values.
    """

    def __init__(self, spark: SparkSession) -> None :
       self.spark = spark

       self.default_values = {
            'tinyint': 0,
            'smallint': 0,
            'int': 0,
            'bigint': 0,
            'float': 0.0,
            'double': 0.0,
            'decimal': Decimal("0"),
            'string': 'N/A',
            'date': dt.date(1900, 1, 1),
            'timestamp': dt.datetime(1900, 1, 1, 0, 0, 0),
            'boolean': False,
        }

    def set_default_for_dtypes(self, dtypes: list[tuple[str, any]]) -> None:
        """Set default values for one ore more datatypes. Note: for decimal(p,s) use 'decimal' as key and e.g. Decimal("-1.0") as the value.

        Args:
            dtypes (list[tuple[str, any]]): A list of tuples of (dtype_as_a_string, default_value). E.g. [('string', 'unknown')]
        """
        for entry in dtypes:
            self.set_default_for_dtype(entry[0], entry[1])

    def set_default_for_dtype(self, dtype: str, default: any) -> None:
        """Set default value for a dataype. Note: for decimal(p,s) use 'decimal' as key and e.g. Decimal("-1.0") as the value.

        Args:
            dtype (str): datatype as a string
            default (any): Default value to be used for the datatype
        """
        self.default_values[dtype]= default

    #
    # Unknown row
    #        

    def add_unknown_row(self, df: DataFrame) -> DataFrame:
        """Adds a row of default values to the dataframe.

        Args:
            df (DataFrame): Source dataframe

        Returns:
            DataFrame: The resulting dataframe with an added row of defaults
        """
        dataTypeList = [dtype for name, dtype in df.dtypes]
        df_dummy = self.spark.createDataFrame(data=[tuple(map(self._create_unknown_entry, dataTypeList)),], schema=df.schema)
        return df.unionByName(df_dummy)

    def _create_unknown_entry(self, data_type: str) -> any:

        # Decimal appears as 'decimal(p,s)', but we want to use just 'decimal' in our dictionary:
        if data_type.startswith('decimal'):
            data_type = 'decimal'

        if not data_type in self.default_values.keys():
            raise DefaultHelperException(f"Default value for {data_type} is missing, please use set_default_for_dtype method to add the default value for this datatype.")
        
        return self.default_values[data_type]

    #
    # Fill NA
    #

    def fill_na(self, df: DataFrame, cols: list[str] = None) -> DataFrame:
        """Fill na values based on the data type for whole dataframe or specific columns.

        Args:
            df (DataFrame): Source dataframe
            cols (list): list of the columns we would like to fill na

        Returns:
            DataFrame: The resulting dataframe without na values for the whole dataframe or for specific columns
        """
        if not cols:
            cols = df.columns
            
        for col in cols:
            data_type = [t[1] for t in df.dtypes if t[0] == col][0]

            # Decimal appears as 'decimal(p,s)', but we want to use just 'decimal' in our dictionary:
            if data_type.startswith('decimal'):
                data_type = 'decimal'

            if data_type in self.default_values:
                replacement_value = self.default_values[data_type]
                df = df.withColumn(col, F.when(df[col].isNull(), replacement_value).otherwise(df[col]))
            else:
                raise DefaultHelperException(f"Default value for {data_type} is missing, please use set_default_for_dtype method to add the default value for this datatype.")
                
        return df