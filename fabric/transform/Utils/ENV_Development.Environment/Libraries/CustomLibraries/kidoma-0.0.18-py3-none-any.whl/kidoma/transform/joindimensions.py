from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col
from typing import Callable

class JoinDimensionsException(Exception):
    """Exception class used in the JoinDimensions class
    """
    def __init__(self, message: str):
        super().__init__(message)    

class Dimension:
    """Describes a dimension
    """
    def __init__(self, 
                name:str, 
                srckey:str, 
                destkey:str, 
                join_cond: list[tuple[str,str]],
                keep_dim_cols: list[str] = [],
                remove_join_cols_from_fact = True
                ) -> None:
        self.name = name
        self.srckey = srckey
        self.destkey = destkey
        self.join_cond = join_cond
        self.keep_dim_cols = keep_dim_cols
        self.remove_join_cols_from_fact = remove_join_cols_from_fact

    def from_dataframe(self, df_dim: DataFrame):
        return DimensionWithDataFrame(df_dim, self.name, self.srckey, self.destkey, self.join_cond, self.keep_dim_cols, self.remove_join_cols_from_fact)

class DimensionWithDataFrame(Dimension):
    """Describes a dimension and provides a ready loaded DataFrame for it. The columns needed per the descriptive fields
    have to be present in the DataFrame.
    """
    def __init__(self,
                df_dim: DataFrame,
                name:str, 
                srckey:str, 
                destkey:str, 
                join_cond: list[tuple[str,str]],
                keep_dim_cols: list[str] = [],
                remove_join_cols_from_fact = True
                ) -> None:
        self.df_dim = df_dim
        super().__init__(name, srckey, destkey, join_cond, keep_dim_cols, remove_join_cols_from_fact)

class JoinDimensions:
    """Provides a method to join 1..n dimensions to a fact table.
    """

    def __init__(self, spark: SparkSession) -> None:
        self.spark = spark

    def join_dimensions(self, 
                        df_fact: DataFrame, 
                        dim_descriptors: list[Dimension],
                        get_dim_path: Callable[[str], str] = None,
                        undefined_key:int = -1
                        ) -> DataFrame :
        """Perform dimension joins on a given fact dataframe. Dimensions are given by a list of descriptors.

        Args:
            df_fact (DataFrame): The fact table loaded to a dataframe
            dim_descriptors (list[Dimension]): A list of dimensions with names, key / join columns etc. and possibly already loaded dataframes.
            get_dim_path (Callable[[str], str]): A callback returning the delta path for a given dimension by name. Needed if loaded dataframes aren't provided for all dims. Defaults to None.
            undefined_key (int, optional): The dimension key to be used if no dimension entry is found. Defaults to -1.

        Returns:
            DataFrame: The fact dataframe with added dimension key columns
        """

        df = df_fact

        # Join columns in the fact table could be used by more than one dimension join.
        # -> Collect the columns to be removed in a set. At the end remove them together.
        join_cols_to_remove_from_fact = set([])

        for dimension in dim_descriptors:

            print(f"Joining {dimension.name}: ", dimension.srckey, "->", dimension.destkey)

            # Either a DataFrame for the dimension is provided ...
            if isinstance(dimension, DimensionWithDataFrame):
                df_dim = dimension.df_dim
            # ... or we load the DataFrame now:                
            else:
                if get_dim_path is None:
                    raise JoinDimensionsException(F"No DataFrame provided for {dimension.name} and no callback get_dim_path() provided. Provide a DataFrame or a callback.")
                
                df_dim = self.spark.read.format("delta").load(get_dim_path(dimension.name))
                
            # .join_cond is a list of tuples from fact -> dim.
            # In the dim DataFrame we need only the key column and the join columns -
            # plus any given .keep_dim_cols not yet included
            join_cols = list(map(lambda x: x[1], dimension.join_cond))

            join_cols_to_keep = list(set(dimension.keep_dim_cols).intersection(join_cols))
            other_cols_to_keep = list(set(dimension.keep_dim_cols).difference(join_cols_to_keep))
            
            needed_cols = [dimension.srckey] + join_cols + other_cols_to_keep
            print(f"Needed columns: {needed_cols}")            
            df_dim = df_dim.select(needed_cols)

            # Rename for e.g. DateKey -> DateInvoiceKey:
            if dimension.srckey != dimension.destkey:
                df_dim = df_dim.withColumnRenamed(dimension.srckey, dimension.destkey)   

            # NULL safe JOIN with <=> / eqNullSafe() from .join_cond - tuples:
            cond = list(map(lambda x : (col("df_fact." + x[0]).eqNullSafe(col("df_dim." + x[1]))), dimension.join_cond))
            print("Join by ", cond)

            # Perform the join:
            df = df.alias("df_fact") \
                .join(df_dim.alias("df_dim"), cond, "LEFT")

            # From the dim table only keep the key column, drop the dim join columns -
            # but honor .keep_dim_cols:
            jcols_to_remove = list(set(join_cols).difference(join_cols_to_keep))
            for jcol in jcols_to_remove:
                df = df.drop(col("df_dim." + jcol))

            # Prefix any columns kept from the dim
            for dcol in dimension.keep_dim_cols:
                df = df.withColumn(dimension.name + "_" + dcol, col("df_dim." + dcol)) # not using .withColumnRenamed on purpose - might spill to fact columns!
                df = df.drop(df_dim[dcol])

            # From the fact table remove the join columns later - 
            # but honor remove_join_cols_from_fact
            if dimension.remove_join_cols_from_fact:
                join_cols_to_remove_from_fact = join_cols_to_remove_from_fact.union(join_cols)

        # Undefined dim keys to undefined_key:
        fills = dict.fromkeys(list(d.destkey for d in dim_descriptors), undefined_key)
        df = df.fillna(fills)

        # Remove join cols from fact table
        for jcol in list(join_cols_to_remove_from_fact):
            df = df.drop(col("df_fact." + jcol))

        return df