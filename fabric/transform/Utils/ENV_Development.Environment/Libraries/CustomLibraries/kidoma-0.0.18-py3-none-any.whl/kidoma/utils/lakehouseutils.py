from notebookutils import mssparkutils
from datetime import datetime


class LakehouseUtils:
    def __init__(self, source_sytem: str, entity: str):
        self.source_system = source_sytem
        self.entity = entity

    def get_file_path(
        self, lakehouse: str, delta: bool = True, date: str = "latest"
    ) -> str:
        """Returns file path.

        Args:
            lakehouse (str): Name of lakehouse
            source_system (str): Name of source system
            entity (str): name of entity
            delta (bool, optional): If delta load is needed. Defaults to True.
            date (str, optional): Date of desired file. Defaults to "latest".

        Returns:
            file_path (str): Path of target file.
        """
        # TODO: add Landing/Conformance and Version to path

        workspace_id = mssparkutils.lakehouse.get(lakehouse).workspaceId
        lakehouse_path = f"abfss://{workspace_id}@onelake.dfs.fabric.microsoft.com/{mssparkutils.lakehouse.get(lakehouse).id}"

        load_type = "delta"
        if not delta:
            load_type = "full"

        if date == "latest":
            folder_path_until_year = (
                f"{lakehouse_path}/Files/{self.source_system}/{self.entity}/{load_type}"
            )
            latest_year = sorted(
                [folder.name for folder in mssparkutils.fs.ls(folder_path_until_year)]
            )[-1]
            folder_path_until_month = f"{folder_path_until_year}/{latest_year}"
            latest_month = sorted(
                [folder.name for folder in mssparkutils.fs.ls(folder_path_until_month)]
            )[-1]
            folder_path_until_day = f"{folder_path_until_month}/{latest_month}"
            latest_day = sorted(
                [folder.name for folder in mssparkutils.fs.ls(folder_path_until_day)]
            )[-1]
            folder_path = f"{folder_path_until_day}/{latest_day}"

        else:
            date_converted = datetime.strptime(date, "%Y-%m-%d")
            date_sub_path = f"year={date_converted.year}/month={date_converted.month if date_converted.month > 9 else f'0{date_converted.month}'}/day={date_converted.day if date_converted.day > 9 else f'0{date_converted.day}'}"
            folder_path = f"{lakehouse_path}/Files/{self.source_system}/{self.entity}/{load_type}/{date_sub_path}"

        folder_content = [f.name for f in mssparkutils.fs.ls(folder_path)]
        match len(folder_content):
            case 0:
                raise ValueError("Target folder does not contain any files.")
            case 1:
                file_path = f"{folder_path}/{folder_content[0]}"
                return file_path
            case _:
                raise ValueError(
                    "Target folder contains for than one file. Please check source files."
                )
